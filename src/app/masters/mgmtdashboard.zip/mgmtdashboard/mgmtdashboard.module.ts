import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MgmtdashboardRoutingModule } from './mgmtdashboard-routing.module';
import { MgmtdashboardComponent } from './mgmtdashboard.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    MgmtdashboardRoutingModule
  ],
  declarations: [
    MgmtdashboardComponent
  ]
})
export class MgmtdashboardModule { }
