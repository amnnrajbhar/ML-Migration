import { Component, OnInit } from '@angular/core';
import { HttpService } from '../../shared/http-service';
import { APIURLS } from '../../shared/api-url';
import { AppComponent } from '../../app.component';
import { AuthData } from '../../auth/auth.model';

import { Assessment } from '../assesment/assessment.model';
import { Http, RequestOptions, Headers } from '@angular/http';
import { PCP } from '../../pcp-form/pcp.model';
import { SbuMasterView } from '../../pcp-form/sbumasterview.model';
import { KRAs } from '../../pcp-form/kras.model';
import { SoftSkills } from '../../pcp-form/softskills.model';
import { NexYrKras } from '../../pcp-form/nextyrkra.model';
import { OverallRatingDetails } from '../../pcp-form/overallratingdetails.model';
import { TrainingDetails } from '../../pcp-form/trainingdetails.model';
import { Router } from '@angular/router';
import { User } from '../user/user.model';

declare var jQuery: any;
import { Chart } from  'chart.js';
import { EmployeeAddressView } from '../../pcp-form/employeeaddressview.model';
import { EmployeeOtherDetailsView } from '../approval/employeeotherdetailsview.model';
import { Recommendations } from '../approval/recommendations.model';
import swal from 'sweetalert';

import * as jspdf from 'jspdf';  
import html2canvas from 'html2canvas';  
import { ExcelService } from '../../shared/excel-service';

@Component({
  selector: 'app-mgmtdashboard',
  templateUrl: './mgmtdashboard.component.html',
  styleUrls: ['./mgmtdashboard.component.css']
})
export class MgmtdashboardComponent implements OnInit {


  isAppraiser = false;
  overallRatingRecordFound: boolean = false;
  trainingRecordFound: boolean = false;
  recommendationRecordFound: boolean = false;
  overallRatingDetails: any;
  recommendationDetails: any;
    trainingDetails: any;
  validatedForm: boolean = false;
  usrid: number;
  public assessmentId: number= 0;
  designationList: any[]=[[]];
  id: string = '';
  eid: number = 0;
  profileId: string = '';
  fname: string = "";
  lname: string = "";
  desig: string = "";
  joining: string = "";
  competency: string = "";
  location: string = "";
  skillarea: string = "";
roleid:number;
redirecturl:string="";
  isLoading: boolean = false;
  ratingClicked: number;
  selectedEmpRoleID:number =0;
  itemIdRatingClicked: string;
  starRating: boolean[] = [true,true,true,true,true];
  assessList: any[];
  currentKra: any[];
  oldcurrentKra: any[];
  nextKra: any[];
  assessmentapproveId:number;
  assessmentDetailsList: any[];
  assessmentDetailsList1: any[];
  assessmentMasterList: any[];
  pcpList: PCP[];
  joining1: Date;
  todayDate: Date;
  manager: string = "";
  reportingmanager: string = "";
  jobDescription: string = "";
  calenderId: number = 0;
  current = [];
  nextYr = [];
  temp: {id:number, fkCalendarId: number, fkProfileId: number, skills: string, fkAssesmentId: number, description: string, isActive: boolean, 'self_assessment_rating': [boolean,boolean,boolean,boolean,boolean] , 'selfRating': number,'final_assessment_rating':  [boolean,boolean,boolean,boolean,boolean], 'finalRating': number}[]=[]; 
  recommItem: Recommendations = this.recommItem = new Recommendations(0,0, '',0, 0,0,0,0,0,0,0,'',0,'',0,'',true); 
  
  assesmentDetails1: SoftSkills = this.assesmentDetails1 = new SoftSkills(0,'',0,0,0,true);
  assessmentItem: Assessment = this.assessmentItem = new Assessment(0, '', '', 0,0,'',true, true, true, true, true, true,true, true, true,'' );
  assessmentResponse: Assessment = this.assessmentItem = new Assessment(0, '', '', 0,0,'',true, true, true, true, true, true,true, true, true,'' );
  overallRatingItem: OverallRatingDetails = this.overallRatingItem = new OverallRatingDetails(0, 0, 0, 0, '', 0,'',0,'',true);
  trainingItem: TrainingDetails = this.trainingItem = new TrainingDetails(0, 0, '', '', 0,'',0,'',true);
  
  nextYrKraDetails: NexYrKras = this.nextYrKraDetails = new NexYrKras(0,'','','',0,'',0,'',0,'',true);
  currentYear: any[];
  overallRatingDetailsList: any[]; 
  errMsg: string = "";
  errMsgPop1: string = "";
  isLoadingPop: boolean = false;
  isLoading1: boolean = false;
  isLoadPop: boolean = false;
  errMsgPop: string = "";
  isEdit: boolean = false;
  public employeeid: number;
  public sbuid: number;
  public completedemployeeList: any[];
  public incompletedemployeeList: any[];
  formData: FormData = new FormData();
  file: File;successMsg: string = "";
  path: string = "";
  isFifthLevelApproved: boolean = false;
  isFourthLevelApproved: boolean = false;
  exportList: any[];
  payrollData: any;
  appraisalDetailsData: any;
  employeeDetailsList: any;
  competencyDetailsList: any;
  sbuDetailsList: any;
  
  constructor(private appService: AppComponent, private httpService: HttpService, private router: Router, private excelService:ExcelService) { }
  getDesignationMasterList(){
    this.errMsg = "";
    this.isLoading = true;
    // this.httpService.getById(APIURLS.BR_EMPLOYEEMASTER_API,this.usrid).then((data: any) => {
    //   this.sbuid = data['fkSbuId']; 
      this.httpService.getById(APIURLS.BR_MASTER_HRVIEWDASHBOARD_API,this.usrid).then((data: any) => {
        
            this.EmployeeList = data['hGridDatas'];
          console.log(this.EmployeeList);
         
// this.completedemployeeList = this.EmployeeList.filter(x=>x.hGridEmpData[42] == "True");
// this.reInitDatatable();
// this.incompletedemployeeList = this.EmployeeList.filter(x=>x.hGridEmpData[42] == "False");
// this.reInitDatatable();
this.isLoading = false;
           this.getDesignationList();
             {
      
              this.chart = new Chart('pie2', {
                type: 'pie',
                data: {
                  labels: ["Completed", "Incomplete"],
                  datasets: [{
                    label: "Overall Sbu",
                    backgroundColor: ["#135890", "#8e5ea2","#3cba9f","#e8c3b9","#c45850"],
                    data:  data['hPieChartData']
                  }]
                },
                options: {
                  title: {
                    display: true,
                    text: 'Overall Sbu',
                    
                  },
                  'onClick' : function (evt, item) {
                    var activePoints = this.chart.getElementsAtEvent(evt);
                    var firstPoint = activePoints[0];
                    var label = this.chart.data.labels[firstPoint._index];
                    var value = this.chart.data.datasets[firstPoint._datasetIndex].data[firstPoint._index];
                 //   alert(label + ": " + value);
                    if(label == "Completed"){
                    jQuery("#myModal").modal('show');
                    
                  }
                  if(label =="Incomplete")
                  {
                    jQuery("#myModal1").modal('show');
                  }
                }
                }
               
                 
          });
             }
             {
      
              this.chart = new Chart('bar', {
                type: 'bar',
                data:  {
                  labels: ["Elotouch", "PMS", "Tyco", "Test Project"],
                  datasets: [{
                      label: "Completed",
                      backgroundColor: "#135890",
                      borderColor: "#135890",
                      data: [3,4,12,11]
                    }, {
                      label: "Incomplete",
                      backgroundColor: "#e8c3b9",
                      borderColor: "#e8c3b9",
                      data: [2,1,4,2]
                    }]
                },
                options: {
                  scales: {
                    xAxes: [{stacked: true}],
                    yAxes: [{
                      stacked: true,
                      ticks: {
                        beginAtZero: true 
                       }
                    }]
                  }
                }
              });
             }
       this.reInitDatatable();
        
    // }).catch(error => {
    //     this.isLoading = false;
    //     this.EmployeeList = [];
    // });
        
    }).catch(error => {
        this.isLoading = false;
        this.EmployeeList = [];
    });
    
  }
  private initDatatable(): void {
    let exampleId: any = jQuery('#desigTable');
    this.tableWidget = exampleId.DataTable();
  }

  private reInitDatatable(): void {
    if (this.tableWidget) {
        this.tableWidget.destroy()
        this.tableWidget = null
    }
    setTimeout(() => this.initDatatable(), 0)
}
fun()
{

}

exportAsXLSX():void {
  this.exportList=[];
  //var templist=this.assessList.length;
  debugger;
  // for(var i=0; i<=this.EmployeeList.length-1;i++) {
  for(let emp of this.EmployeeList) {
    
    // var expListItem={Name:emp.hGridEmpData[2], Designation: emp.hGridEmpData[3], EmpId: emp.hGridEmpData[1], ManagerName: emp.hGridEmpData[39],
    //   Emp_Score:emp.hGridEmpData[6], Mgr_Score:emp.hGridEmpData[48],Mgr_Rating:emp.hGridEmpData[49],Year: emp.hGridEmpData[7], Status: emp.hGridEmpData[8] };
    // var expListItem={E_Code: emp.hGridEmpData[1], Name: emp.hGridEmpData[2],  DOJ: emp.hGridEmpData[13],  
    //   Total_Exp: emp.hGridEmpData[23],  Qual: emp.hGridEmpData[28],  YOP: emp.hGridEmpData[29],  
    //   Designation: emp.hGridEmpData[3],  Current_Annual_CTC_Total: this.getCurrentCTC(emp.hGridEmpData[1]),  
    //   Fixed_CTC: this.getFixedCTC(emp.hGridEmpData[1]),  VP: this.getVP(emp.hGridEmpData[1]),  
    //   SCORES_being_generated_from_Tool: emp.hGridEmpData[48] ,
    //   Rating_SMART: this.getSMART(emp.hGridEmpData[48]),  Normalized_SCORE_by_SBU_Rating_SMART:'' ,    
    //   Skills: emp.hGridEmpData[32] ,  Skills_Criticality:'',  
    //   Current_Status_: this.getCurrStatus(emp.hGridEmpData[1]) , 
    //   If_unbilled_then_what_is_the_status_or_action_plan:'' ,  Billing_Rate: this.getBillAmt(emp.hGridEmpData[1]) ,  
    //   Current_Project: emp.hGridEmpData[33],  Recommendation_by_Mgr: this.getRecommHike(emp.hGridEmpData[1]), 
    //   Recommendation_by_Mgr_Fixed: this.getRecommFixedHike(emp.hGridEmpData[1]),  
    //   Recommendation_by_Mgr_VP: this.getRecommVP(emp.hGridEmpData[1]),  Appraised_CTC_as_per_Manager: '',  
    //   Fixed: '' ,  VP_Incentive: '',  Kitty_Used:'' ,  Revised_Designation: this.getRecommDesig(emp.hGridEmpData[1]),  
    //   Comments_Concern_from_employee:'' ,  Appraisal_Due_Date:'' ,  Appraisal_Month:'' ,  
    //   'Pro-rated_no_of_Months':'' ,  Previous_Appraisal_Date:'' ,  Competency: this.getComp(emp.hGridEmpData[1]),  
    //   Competency_Head: this.getCompHead(emp.hGridEmpData[1]),  SBU: this.getSBU(emp.hGridEmpData[1]), 
    // };
 var expListItem = {
  'E Code': emp.hGridEmpData[1], 'Name': emp.hGridEmpData[2], 'DOJ': emp.hGridEmpData[13], 
  'Total Exp.': emp.hGridEmpData[23], 'Qual': emp.hGridEmpData[28], 'YOP': emp.hGridEmpData[29], 
  'Designation': emp.hGridEmpData[3], 'Current Annual CTC(INR) Total': this.getCurrentCTC(emp.hGridEmpData[1]), 
  'Fixed CTC(INR)': this.getFixedCTC(emp.hGridEmpData[1]), 'VP(INR)': this.getVP(emp.hGridEmpData[1]), 
  'SCORES (being generated from Tool)': emp.hGridEmpData[48] , 
  'Rating(SMART)': this.getSMART(emp.hGridEmpData[48]), 'Normalized SCORE (by SBU) Rating(SMART)': '', 
  'Skills': emp.hGridEmpData[32] , 'Skills Criticality (yes / no)': '', 
  'Current Status (Billed / Unbilled / Shadow / bench)': this.getCurrStatus(emp.hGridEmpData[1]) , 
  'If unbilled, then what is the status or action plan': '', 'Billing Rate - INR': this.getBillAmt(emp.hGridEmpData[1]) , 'Current Project': emp.hGridEmpData[33], 'Recommendation (% hike ) (by Mgr)': this.getRecommHike(emp.hGridEmpData[1]), 'Recommendation (% hike ) (by Mgr) - Fixed': this.getRecommFixedHike(emp.hGridEmpData[1]), 'Recommendation (% hike ) (by Mgr)- VP%': this.getRecommVP(emp.hGridEmpData[1]), 'Appraised CTC (as per Manager)INR': '', 'Fixed(INR)': '', 'VP(INR)/Incentive': '', 'Kitty Used': '', 'Revised Designation': this.getRecommDesig(emp.hGridEmpData[1]), 'Comments / Feedback / Inputs / Concern from employee': '', 'Appraisal Due Date': '', 'Appraisal Month': '', 'Pro-rated no. of Months': '', 'Previous Appraisal Date': '', 'Competency': this.getComp(emp.hGridEmpData[1]), 'Competency Head': this.getCompHead(emp.hGridEmpData[1]), 'SBU': this.getSBU(emp.hGridEmpData[1]), 'Base Location': emp.hGridEmpData[14], 'Email': emp.hGridEmpData[4]
 };   
    this.exportList.push(expListItem);
  //  //console.log('export list'+this.exportList);
  }

  //this.exportList = {  }
  
  
  this.excelService.exportAsExcelFile(this.exportList, 'ManagementReport');
}

onopen()
{
  for(let des of this.EmployeeList){
   if(des['12']=='True')
      this.isEdit=true;
  }
  jQuery("#myModal").modal('hide');
  this.errMsgPop = "";
  jQuery("#myModalAllData").modal('show');
}

review(emp: any){
 
  this.employeeid = emp;
  this.getEmployeeData();
  // this.employeeid = emp;
  
  jQuery("#myModalAllData").modal('show');
}
draft(emp: any){
 
  this.employeeid = emp;
  this.getEmployeeData();
  // this.employeeid = emp;
  
  jQuery("#myDraftModel").modal('show');
  // jQuery("#mydraftPanelModal").modal('show');
}
closeModal() {
  // ////console.log('testpop')
  jQuery("#myModal").modal('hide');
  
  // window.location.reload();
}
closeDraftModal() {
  // ////console.log('testpop')
  jQuery("#myDraftModel").modal('hide');
  
  // window.location.reload();
}
closedraftPanelModal() {
  // ////console.log('testpop')
  jQuery("#mydraftPanelModal").modal('hide');
  
  // window.location.reload();
}

public captureScreen()  
{  
  var data = document.getElementById('contentToConvert');  
  html2canvas(data).then(canvas => {  
    var imgData = canvas.toDataURL('image/png');

    var imgWidth = 210; 
    var pageHeight = 295;  
    // var canWidth = 675;
    var canWidth = canvas.width;
    // var imgHeight = canvas.height * imgWidth / canvas.width;
    var imgHeight = canvas.height * imgWidth / canWidth;
    var heightLeft = imgHeight;

    var doc = new jspdf('p', 'mm');
    var position = 0;
    doc.setPage(doc.internal.getNumberOfPages());
    doc.setTextColor(0, 0, 0);
    doc.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
    heightLeft -= pageHeight;

    while (heightLeft >= 0) {
      position = heightLeft - imgHeight;
      doc.addPage();
      doc.setPage(doc.internal.getNumberOfPages());
      doc.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;
    }
    doc.save(this.fname+'.pdf');

  });  
} 
public captureScreen2()  
{  
  var data = document.getElementById('contentToConvert2');  
  html2canvas(data).then(canvas => {  
    var imgData = canvas.toDataURL('image/png');

    var imgWidth = 210; 
    var pageHeight = 295;  
    // var canWidth = 675;
    var canWidth = canvas.width;
    // var imgHeight = canvas.height * imgWidth / canvas.width;
    var imgHeight = canvas.height * imgWidth / canWidth;
    var heightLeft = imgHeight;

    var doc = new jspdf('p', 'mm');
    var position = 0;
    doc.setPage(doc.internal.getNumberOfPages());
    doc.setTextColor(0, 0, 0);
    doc.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
    heightLeft -= pageHeight;

    while (heightLeft >= 0) {
      position = heightLeft - imgHeight;
      doc.addPage();
      doc.setPage(doc.internal.getNumberOfPages());
      doc.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;
    }
    doc.save(this.fname+'.pdf');
  });  
} 
public captureScreen3()  
{  
  var data = document.getElementById('contentToConvert3');  
  html2canvas(data).then(canvas => {  
    var imgData = canvas.toDataURL('image/png');

    var imgWidth = 210; 
    var pageHeight = 295;  
    // var canWidth = 675;
    var canWidth = canvas.width;
    // var imgHeight = canvas.height * imgWidth / canvas.width;
    var imgHeight = canvas.height * imgWidth / canWidth;
    var heightLeft = imgHeight;

    var doc = new jspdf('p', 'mm');
    var position = 0;
    doc.setPage(doc.internal.getNumberOfPages());
    doc.setTextColor(0, 0, 0);
    doc.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
    heightLeft -= pageHeight;

    while (heightLeft >= 0) {
      position = heightLeft - imgHeight;
      doc.addPage();
      doc.setPage(doc.internal.getNumberOfPages());
      doc.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;
    }
    doc.save(this.fname+'.pdf');

  });  
} 
public captureScreen4()  
{  
  var data = document.getElementById('contentToConvert4');  
  html2canvas(data).then(canvas => {  
    var imgData = canvas.toDataURL('image/png');

    var imgWidth = 210; 
    var pageHeight = 295;  
    // var canWidth = 675;
    var canWidth = canvas.width;
    // var imgHeight = canvas.height * imgWidth / canvas.width;
    var imgHeight = canvas.height * imgWidth / canWidth;
    var heightLeft = imgHeight;

    var doc = new jspdf('p', 'mm');
    var position = 0;
    doc.setPage(doc.internal.getNumberOfPages());
    doc.setTextColor(0, 0, 0);
    doc.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
    heightLeft -= pageHeight;

    while (heightLeft >= 0) {
      position = heightLeft - imgHeight;
      doc.addPage();
      doc.setPage(doc.internal.getNumberOfPages());
      doc.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;
    }
    doc.save(this.fname+'.pdf');

  });  
} 
public captureScreen5()  
{  
  var data = document.getElementById('contentToConvert5');  
  html2canvas(data).then(canvas => {  
    var imgData = canvas.toDataURL('image/png');

    var imgWidth = 210; 
    var pageHeight = 295;  
    // var canWidth = 675;
    var canWidth = canvas.width;
    // var imgHeight = canvas.height * imgWidth / canvas.width;
    var imgHeight = canvas.height * imgWidth / canWidth;
    var heightLeft = imgHeight;

    var doc = new jspdf('p', 'mm');
    var position = 0;
    doc.setPage(doc.internal.getNumberOfPages());
    doc.setTextColor(0, 0, 0);
    doc.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
    heightLeft -= pageHeight;

    while (heightLeft >= 0) {
      position = heightLeft - imgHeight;
      doc.addPage();
      doc.setPage(doc.internal.getNumberOfPages());
      doc.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;
    }
    doc.save(this.fname+'.pdf');

  });  
} 

getDesignationList(){
    this.httpService.get(APIURLS.BR_DESIGNATION_API).then((data: any) => {
      this.isLoading = false;
      console.log('designation');
      console.log(data);
      if (data.length > 0) {
          this.designationList = data;
          console.log('designation');
          console.log(data);
          // this.parentList = this.designationList.filter(s => s.isActive != false);
          //training details
          
    }
  }).catch(error => {
    this.isLoading = false;
    // this.designationList = [];
  });
}
getEmployeeDetails(){
    this.httpService.get(APIURLS.BR_EMPLOYEEMASTER_API_GET).then((data: any) => {
      this.isLoading = false;
      console.log('emp');
      console.log(data);
      if (data.length > 0) {
          this.employeeDetailsList = data;
          console.log('designation');
          console.log(data);
          // this.parentList = this.designationList.filter(s => s.isActive != false);
          //training details
          
    }
  }).catch(error => {
    this.isLoading = false;
    // this.designationList = [];
  });
}
getCompentencyList(){
    this.httpService.get(APIURLS.BR_COMPETENCY).then((data: any) => {
      this.isLoading = false;
      console.log('emp');
      console.log(data);
      if (data.length > 0) {
          this.competencyDetailsList = data;
          console.log('designation');
          console.log(data);
          // this.parentList = this.designationList.filter(s => s.isActive != false);
          //training details
          
    }
  }).catch(error => {
    this.isLoading = false;
    // this.designationList = [];
  });
}
getSBUList(){
    this.httpService.get(APIURLS.BR_MASTER_SBU_All).then((data: any) => {
      this.isLoading = false;
      console.log('emp');
      console.log(data);
      if (data.length > 0) {
          this.sbuDetailsList = data;
          console.log('designation');
          console.log(data);
          // this.parentList = this.designationList.filter(s => s.isActive != false);
          //training details
          
    }
  }).catch(error => {
    this.isLoading = false;
    // this.designationList = [];
  });
}


  ngOnInit(){ 
    this.path = this.router.url;
    var chkaccess = this.appService.validateUrlBasedAccess(this.path);
    // if(chkaccess == true){

    let authData: AuthData = JSON.parse(localStorage.getItem('currentUser'));
    this.usrid = authData.uid;
    this.roleid = authData.roleId;
    
    this.getDesignationMasterList();
    this.getEmployeeDetails();
    this.getCompentencyList();
    this.getSBUList();
    this.getPayrollData();
    this.getAppraisalDetails();
    this.checkInitiated();
  // }
  // else 
  //   this.router.navigate(["/unauthorized"]);
    
  }
  chart: any;
  public tableWidget: any;
  selParentId: any;
  EmployeeList: any[];
  public formStatus: boolean;
  public isFirstLevelApproved: boolean;
  public isSecondLevelApproved: boolean;
  BellCurveManagerRatingList: any;
  BellCurveSystemRatingList: any;
  parentList: any[];
  selParentRole: any;
  selParentRoleList: any;

self_assessment_rating: [boolean,boolean,boolean,boolean,boolean];
selfRating = [0,0,0,0,0,0,0,0,0,0,0];
sofSkillScore = 0; sofSkillTotal = 0;
    rating = 0;
    score = 0;
    empScore = 0;
    datex: Date;

setSelfRating(data: any, rec: any){  
  //console.log('self rating i:'+ data + 'record  num:'+rec);
  this.rating= data + 1;  
  for(var i=0;i<=4;i++){  
  this.temp[rec].self_assessment_rating[i] = (i<=data)? false : true;
  }
  this.temp[rec].selfRating = this.rating;
}

setFinalRating(data: any, rec: any){  
  //console.log('final rating i:'+ data + 'record  num:'+rec);
  this.rating= data + 1;  
  for(var i=0;i<=4;i++){  
    this.temp[rec].final_assessment_rating[i] = (i<=data)? false : true;
  }
  this.temp[rec].finalRating = this.rating;
  this.getSoftSkillScore();
    
}

setInitialSelfRating(){  
  for(var j=0;j<this.current.length;j++){
    //console.log('............'+this.current[j].selfRating);
    for(var i=0;i<=4;i++){  
        this.current[j].self_assessment_rating[i] = (i<this.current[j].selfRating)? false : true;
    }
  }
    for(var j=0;j<this.current.length;j++){
      //console.log('............'+this.current[j].finalRating);
      for(var i=0;i<=4;i++){  
        this.current[j].final_assessment_rating[i] = (i<this.current[j].finalRating)? false : true;
      }
     }
}

setInitialSoftSkillRating(){
  // debugger;
  //softskill self
  //console.log('initalizing rating');
    for(var j=0;j<this.temp.length;j++){
      for(var i=0;i<=4;i++){  
        this.temp[j].self_assessment_rating[i] = (i<this.temp[j].selfRating)? false : true;
      }
  }
    for(var j=0;j<this.temp.length;j++){
      //console.log('final............'+this.temp[j].finalRating);
      for(var i=0;i<=4;i++){  
        this.temp[j].final_assessment_rating[i] = (i<this.temp[j].finalRating)? false : true;
      }
  }
  
  //console.log(this.temp);
}

setDelSelfRating(data: any, rec: any){  
  this.rating= data + 1;  
  for(var i=0;i<=4;i++){  
    this.current[rec].self_assessment_rating[i] = (i<=data)? false : true;
  }
  this.current[rec].selfRating = this.rating;
}
setDelFinalRating(data: any, rec: any){  
  this.rating= data + 1;  
  for(var i=0;i<=4;i++){  
    this.current[rec].final_assessment_rating[i] = (i<=data)? false : true;
  }
  this.current[rec].finalRating = this.rating;
  this.getTotalScore();
}

onChangeWeightage(){
  this.getTotalScore();
  // this.getTotalWeightage();
}
totalScore = 0;
totalWeightage=0;
totalEmpScore = 0;

getTotalScore(){ 
this.totalScore = 0;
this.totalEmpScore = 0;
this.score = 0;
this.empScore = 0;
this.totalWeightage = 0;
for(let i=0;i<this.current.length;i++){
  this.current[i].score = (this.current[i].finalRating * this.current[i].weightage /100);
  this.current[i].empScore = this.current[i].selfRating * this.current[i].weightage /100;
  this.totalScore = this.totalScore + this.current[i].score;
  this.totalEmpScore = this.totalEmpScore + this.current[i].empScore;
  this.totalWeightage = (+this.totalWeightage + +this.current[i].weightage);
}
  this.totalEmpScore = this.totalEmpScore * 60/100;
  this.totalScore = this.totalScore * 60/100;
}

getOverallRating(){
  this.getTotalScore();
  this.getSoftSkillScore();
  this.overallRatingItem.rating = this.totalScore + this.sofSkillFinalScore;
  this.overallRatingItem.ratingEmp = this.totalEmpScore + this.sofSkillFinalScoreEmp;
  this.setStarRating(this.overallRatingItem.rating);
}

// getTotalWeightage(){
//   this.totalWeightage = 0;
//   for(let i=0;i<this.current.length;i++)
//    this.totalWeightage = (+this.totalWeightage + +this.current[i].weightage);
// }
sofSkillFinalScore = 0;
sofSkillFinalScoreEmp = 0;
getSoftSkillScore(){
  let softSkillTotalEmp = 0;
  let sofSkillScoreEmp = 0;
  this.sofSkillTotal = 0; 
  for(let des of this.temp){
     this.sofSkillTotal = +this.sofSkillTotal + des.finalRating;
     softSkillTotalEmp = softSkillTotalEmp + des.selfRating;
  }
     this.sofSkillScore = +this.sofSkillTotal / this.temp.length;
     sofSkillScoreEmp = softSkillTotalEmp / this.temp.length;

     this.sofSkillFinalScore = +this.sofSkillScore * 40/100;
     this.sofSkillFinalScoreEmp = sofSkillScoreEmp * 40/100;
     
}

setStarRating(data: any){
  this.rating = data + 1;
  for(var i=0;i<=4;i++){  
    this.starRating[i] = (i<=data)? false : true;
  }
}
  
updateCurrentYrDate(event, rec){
  this.current[rec].closure_date = event.target.value;
}
updateNextYrDate(event, rec){
  this.nextYr[rec].closure_date = event.target.value;
}

getCurrentCTC(id: number){
  var temp: any;
  temp = this.payrollData.find(s => s.employeeId == id);
  var name = (typeof temp!= 'undefined')? temp.currentAnnualCtc:'';
  return name;
}
getCurrStatus(id: number){
  var temp: any;
  temp = this.payrollData.find(s => s.employeeId == id);
  var name = (typeof temp!= 'undefined')? temp.currentWorkStatus:'';
  return name;
}
getBillAmt(id: number){
  var temp: any;
  temp = this.payrollData.find(s => s.employeeId == id);
  var name = (typeof temp!= 'undefined')? temp.billingRate:'';
  return name;
}

getSMART(te: number){
  var temp: any;
  // temp = this.overallRatingList.find(s => s.fkAssesmentId == id);
  // var te = (typeof temp != 'undefined')? +temp.rating : '';
  var name='';
  if(te>=4.50 && te<=5)
  name = 'Star';
  else if((te>=3.25 && te<=4.49))
  name = 'Meritorious';
  else if((te>=1.25 && te<=3.24))
  name= 'Achiever';
  else if((te>.50 && te<=1.24))
  name = 'Reasonable';
  else if((te>0 && te<=.40))
  name = 'Trailer';
  return name;
}

getFixedCTC(id: number){
  var temp: any;
  temp = this.payrollData.find(s => s.employeeId == id);
  var name = (typeof temp!= 'undefined')? temp.fixedCtc:'';
  return name;
}
getVP(id: number){
  var temp: any;
  temp = this.payrollData.find(s => s.employeeId == id);
  var name = (typeof temp!= 'undefined')? temp.veriablePay:'';
  return name;
}
getRecommHike(id: number){
  var temp: any;
  temp = this.appraisalDetailsData.find(s => s.employeeId == id);
  var name = (typeof temp!= 'undefined')? temp.recommendationHike:'';
  return name;
}
getRecommFixedHike(id: number){
  var temp: any;
  temp = this.appraisalDetailsData.find(s => s.employeeId == id);
  var name = (typeof temp!= 'undefined')? temp.fixedHike:'';
  return name;
}
getRecommVP(id: number){
  var temp: any;
  temp = this.appraisalDetailsData.find(s => s.employeeId == id);
  var name = (typeof temp!= 'undefined')? temp.variableHike:'';
  return name;
}
getRecommDesig(id: number){
  var temp: any;
  var temp1: any;
  temp = this.appraisalDetailsData.find(s => s.employeeId == id);
  temp1 = (typeof temp != 'undefined')? this.designationList.find(s => s.id === temp.fkRecommendationDesignation): '';
  var name = (typeof temp1!= 'undefined')? temp1.name:'';
  return name;
}
getComp(id: number){
  var temp: any;
  var temp1: any;
  temp = this.employeeDetailsList.find(s => s.employeeId == id);
  temp1 = (typeof temp != 'undefined')? this.competencyDetailsList.find(s => s.id === temp.fkCompetency): '';
  var name = (typeof temp1!= 'undefined')? temp1.name:'';
  return name;
}
getCompHead(id: number){
  var temp: any;
  var temp1: any;
  var temp2: any;
  temp = this.employeeDetailsList.find(s => s.employeeId == id);
  temp1 = (typeof temp != 'undefined')? this.competencyDetailsList.find(s => s.id === temp.fkCompetency): '';
  temp2 = (typeof temp1 != 'undefined')? this.employeeDetailsList.find(s => s.id === temp1.fkHeadEmpId): '';
  var name = (typeof temp2!= 'undefined')? temp2.firstName+' '+temp2.lastName:'';
  return name;
}
getSBU(id: number){
  var temp: any;
  var temp1: any;
  temp = this.employeeDetailsList.find(s => s.employeeId == id);
  temp1 = (typeof temp != 'undefined')? this.sbuDetailsList.find(s => s.id === temp.fkSbuId): '';
  var name = (typeof temp1!= 'undefined')? temp1.name:'';
  return name;
}
// getSBUHead(id: number){
//   var temp: any;
//   var temp1: any;
//   var temp2: any;
//   temp = this.employeeDetailsList.find(s => s.employeeId == id);
//   temp1 = (typeof temp != 'undefined')? this.sbuDetailsList.find(s => s.id === temp.fkSbuId): '';
//   temp2 = (typeof temp1 != 'undefined')? this.employeeDetailsList.find(s => s.id == temp1.fkSbuId): '';
//   var name = (typeof temp2!= 'undefined')? temp2.firstname+' '+temp2.lastname:'';
//   return name;
// }

getAppraisalDetails(){
  this.httpService.get(APIURLS.BR_DETAIL_APPRAISAL_API).then((data: any) => {
    if (data.length > 0) {
      this.appraisalDetailsData = data;
    }
  }).catch(function (error) {
    //console.log('No data captured');
    // this.pcpItem = [];
    this.toastr.error(error,"Error!");
    
});
}

getPayrollData(){
  this.httpService.get(APIURLS.BR_MASTER_EMPLOYEEPAYROLL_API_ALL).then((data: any) => {
    if (data.length > 0) {
      this.payrollData = data;
    }
  }).catch(function (error) {
    //console.log('No data captured');
    // this.pcpItem = [];
    this.toastr.error(error,"Error!");
    
});
}
  getEmployeeData(){
    //console.log(this.employeeid);
    this.httpService.getById(APIURLS.BR_MASTER_EMPLOYEEVIEWDASHBOARD_API,this.employeeid).then((data: any) => {
      this.isLoading = true;
      if (data['eGridDatas']['0']['eGridEmpData'].length > 0) {
        //  debugger;  
        console.log(data['eGridDatas'])    ;
        let dateString = data['eGridDatas']['0']['eGridEmpData']['13'];
        this.todayDate = new Date();
        this.joining1 = new Date(dateString);
        this.id = data['eGridDatas']['0']['eGridEmpData']['0'];
        this.profileId = "1";
        this.eid = data['eGridDatas']['0']['eGridEmpData']['1'];
        this.fname = data['eGridDatas']['0']['eGridEmpData']['2'];
        this.desig = data['eGridDatas']['0']['eGridEmpData']['3'];
        console.log(this.desig);
        // this.joining = data['0']['joiningDate'];
        this.competency = data['eGridDatas']['0']['eGridEmpData']['32'];
        this.location = data['eGridDatas']['0']['eGridEmpData']['14'];
        this.skillarea = data['eGridDatas']['0']['eGridEmpData']['36'];
        this.manager =  data['eGridDatas']['0']['eGridEmpData']['39'];
        this.reportingmanager = data['eGridDatas']['0']['eGridEmpData']['37'];
        this.isSecondLevelApproved = data['eGridDatas']['0']['eGridEmpData']['43'];
        this.isFirstLevelApproved = data['eGridDatas']['0']['eGridEmpData']['42'];
        this.isFourthLevelApproved = data['eGridDatas']['0']['eGridEmpData']['45'];
        this.isFifthLevelApproved = data['eGridDatas']['0']['eGridEmpData']['46'];
        console.log(this.isFourthLevelApproved);
        this.formStatus = data['eGridDatas']['0']['eGridEmpData']['12'];
        this.selectedEmpRoleID = data['eGridDatas']['0']['eGridEmpData']['47'];
  
        
      }
      this.getSavedDetails();
      //console.log('employee details');

  }).catch(function (error) {
      //console.log('No data captured');
      // this.pcpItem = [];
      this.toastr.error(error,"Error!");
      
  });
  this.httpService.getById(APIURLS.BR_MASTER_ASSESMENT_MASTER_DATA_ANY_API, this.employeeid).then((data: any) => {
    if (data.length > 0) {
      // debugger;
      this.assessmentItem = data;
      this.jobDescription = data['0']['jobDescription'];
      this.assessmentId = data[0]['id'];
      //console.log('this.assessmentItem.jobDescription ID.........................................:'+this.assessmentItem.jobDescription);
      this.calenderId = data[0]['fkCalendarId'];
      //console.log('Calendar ID.........................................:'+this.calenderId);
   }}).catch(function (error) {
    //console.log('No data captured');
    this.assessmentItem = [];
   this.isLoading = false;
   });
  }
  onImgFileChange(event: any) {
    this.errMsg = '';
    // debugger;
    this.formData = new FormData();
    let fileList: FileList = event.target.files;
    if (fileList.length > 0) {
        //let file: File = fileList[0];
        this.file = fileList[0];
        this.formData.append("File", this.file);
        // if (this.file.type.indexOf('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') === -1) {
        //     this.errMsg = " Select xlsx File Type to Upload";
        // }
        // else {
        //     //let formData: FormData = new FormData();
        //     this.formData.append("File", this.file);
        // }
    }
    //window.location.reload();
  }
  getSavedDetails(){
    debugger;
    this.nextYr = [];
    this.current = [];
    // this.nextDeletedKraIds = [];
    // this.nextKraIds = [];
  
    // this.fromSubmit = false;
    // this.recommendationRecordFound = false;
    this.trainingRecordFound = false;
    this.overallRatingRecordFound = false;
     debugger;
    this.isLoading = true;
      this.httpService.getById(APIURLS.BR_MASTER_ASSESMENT_MASTER_DATA_ANY_API,this.employeeid).then((data: any) => {
      if (data.length > 0) {
        this.assessmentItem = (data[0] != 'undefined')?data[0]:null;
        this.assessmentItem.jobDescription = data['0']['jobDescription'];
        this.assessmentId = this.assessmentItem.id;
        console.log('this.assessmentId');
        console.log(this.assessmentId);
        this.httpService.getById(APIURLS.BR_KRACURRENTYEAR_GETANY_API, this.assessmentId).then((data_curyr: any) => {
          if (data_curyr.length>0) {
            
            let genId: any = this.current[this.current.length - 1];
            this.currentKra = data_curyr;
            this.current=[];
            for(let des of this.currentKra){
              var temp = {'id': 0, 'name': '', 'task': '', 'weightage': 0, 'closure_date': '', 'self_assessment_rating': [true, true, true, true, true], 'final_assessment_rating':[true, true, true, true, true], 'selfRating': 0, 'finalRating': 0, 'score': 0 };
              temp.id = des.id;
              temp.name = des.kraName;
              temp.task = des.task;
              temp.selfRating = des.assessmentAppraisee;
              temp.finalRating = des.assessmentAppraiser;
              temp.weightage = des.weightage;
              temp.closure_date = des.targetDate;
              this.current.push(temp);
              //console.log('array values'+ this.current[i].selfRating);
            }
            this.errMsgPop = "";
            this.setInitialSelfRating();
            this.getTotalScore();
          
          // else 
          //   this.current = "Data not yet submitted";
          
          console.log('this.selectedEmpRoleID');
        //  console.log(this.selectedEmpRoleID);
          // debugger;
          // softskills
          // this.assessmentMasterList = null;
  
          
          this.httpService.getById(APIURLS.BR_MASTER_SOFTSKILL_GET_BY_API,this.selectedEmpRoleID).then((data_softmaster: any) => {
            if (data_softmaster.length>0) {
              this.assessmentMasterList = data_softmaster;
              this.temp = [];
              this.assessmentMasterList.forEach(element => {
                element.self_assessment_rating = [true, true,true, true, true];
                element.final_assessment_rating = [true, true,true, true, true];
                element.selfRating = 0;
                element.finalRating = 0;
                this.temp.push(element);
              });
              this.assessmentMasterList = data_softmaster;
              console.log('assessment data check');
              console.log(this.assessmentMasterList);
              for(let i=0;i<this.temp.length;i++){
                this.temp[i].id = this.assessmentMasterList[i].id;
                this.temp[i].skills = this.assessmentMasterList[i].skills;
                this.temp[i].description = this.assessmentMasterList[i].description;
              }
            
            
            let itemId = 0;
      debugger;
      let loadedSoftData: boolean = true;
  this.httpService.getById(APIURLS.BR_MASTER_ASSESMENT_DATA_ANY_API, this.assessmentId).then((data_soft: any) => {
          if (data_soft.length>0) {
            this.assessmentDetailsList1 = data_soft;
             for(let i=0;i<this.assessmentDetailsList1.length;i++){
  
                  itemId = this.assessmentDetailsList1[i].fkSoftSkillId;
              // console.log('itemId'+this.assessmentDetailsList1.length);
              this.assesmentDetails1 = this.assessmentDetailsList1.find(s => s.fkSoftSkillId === itemId);
              // let tempRec = this.temp.find(s=> s.id == this.assesmentDetails1.fkSoftSkillId);
              // console.log(this.assesmentDetails1.fkSoftSkillId+'and...........'+tempRec);
              console.log(this.assesmentDetails1);
              this.temp.find(s=> s.id === this.assesmentDetails1.fkSoftSkillId).selfRating = this.assesmentDetails1.assesmentAppraisee;
              this.temp.find(s=> s.id === this.assesmentDetails1.fkSoftSkillId).finalRating = this.assesmentDetails1.assesmentAppraiser;
              if(i==this.assessmentDetailsList1.length-1) { this.setInitialSoftSkillRating(); this.getSoftSkillScore(); console.log('going to initializing/////////'+i);}
            }
  
  
  
  }
     }).catch(error => {
  this.isLoadingPop = false;
  this.errMsgPop = 'Error retreiving training data..';
  }); 
  }
  
            }).catch(error => {
              this.errMsgPop = 'Error retreiving softskill master data..';
            });
          
    //nextyr kra
  this.httpService.getById(APIURLS.BR_KRANEXTYEAR_GETANY_API, +this.assessmentId).then((data_nxyr: any) => {
    // if(!(data_nxyr.length>0)){
    //   this.initialNextKra();
    // }
    // else if(data_nxyr.length>0) {
    // else {
      this.nextKra = data_nxyr;
      this.nextYr = [];
      let i = 0;
      for(let des of this.nextKra){
        var nextY = {'id': 0, 'name': '', 'task': '', 'weightage': 0, 'closure_date': ''};
        nextY.id = des.id;
        nextY.closure_date = des.targetDate;
        nextY.name = des.kraName;
        nextY.task = des.task;
        nextY.weightage = des.weightage;
        this.nextYr.push(nextY);
        // this.nextKraIds.push(des.id);
        // console.log('Date..................'+this.nextKraIds);
        i++;
        // if(i == this.nextKra.length-1) 
      }
      this.getTotalWeightage();
      this.getTotalWeightageNextYr();
    // }
  }).catch(error => {
    this.isLoadingPop = false;
    this.errMsgPop = 'Error saving kra1 data..';
  });
  
      
    // this.getTotalWeightage();
    // this.getTotalWeightageNextYr();
  //   this.httpService.get(APIURLS.BR_DESIGNATION_API).then((data: any) => {
  //     this.isLoading = false;
  //     console.log('designation');
  //     console.log(data);
  //     if (data.length > 0) {
  //         this.designationList = data;
  //         console.log('designation');
  //         console.log(data);
  //         // this.parentList = this.designationList.filter(s => s.isActive != false);
  //         //training details
          
  //   }
  // }).catch(error => {
  //   this.isLoading = false;
  //   // this.designationList = [];
  // });
    this.httpService.getById(APIURLS.BR_DETAILS_ANY_TRAINING_API,this.assessmentId).then((data_training: any) => {
      if (data_training.length>0) {
        // debugger;
        this.trainingItem = data_training['0'];
        this.trainingRecordFound = true;
      }
    }).catch(error => {
      this.isLoading = false;
      // this.trainingItem = null;
    });
        
        
    //overall rating details
    this.httpService.getById(APIURLS.BR_DETAILS_ANY_OVERALLRATING_API, this.assessmentId).then((data_overall: any) => {
      if (data_overall.length>0) {
        this.overallRatingItem = data_overall['0'];
        this.overallRatingRecordFound = true;
        this.setStarRating(this.overallRatingItem.rating);
      }
      
    }).catch(error => {
    this.isLoadingPop = false;
    this.errMsgPop = 'Error retreiving overallrating data..';
    });
    
              this.httpService.getById(APIURLS.BR_DETAIL_APPRAISAL_ANY_API, this.assessmentId).then((data_recom: any) => {
                if (data_recom.length > 0) {
              // debugger;
    
                  this.recommItem = data_recom['0'];
                  this.recommendationRecordFound = true;
                  let desigrecomidfilter = this.recommItem.fkRecommendationDesignation;
                  console.log('recommended designation:...........'+desigrecomidfilter);
                  this.selParentRole = this.designationList.find(s=>s.id === desigrecomidfilter);
                  console.log('recommended designation:.........if..'+this.designationList);

                 }
                else{
                  this.recommItem = new Recommendations(0,0, '',0, 0,0,0,0,0,0,0,'',0,'',0,'',true);
                  console.log('recommended designation:.....else......'+this.designationList);
                  this.recommendationRecordFound = false;
                   let designamefilter=this.desig;
                  console.log('recommended designatiod   esignamefiltern:.....else......'+designamefilter);

                  //  this.selParentRole = this.designationList.find(s=>s.isActive!=false);
                  this.selParentRole = this.designationList.find(s=>s.name == designamefilter);
                }
                }).catch(error => {
                  this.isLoadingPop = false;
                  // this.errMsgPop = 'Error retreiving recommendation data..';
                });
      
     
    
    this.httpService.getById(APIURLS.BR_DETAILS_ANY_OVERALLRATING_API, this.assessmentId).then((data_overall: any) => {
      if (data_overall.length>0) {
        // debugger;
        this.overallRatingDetails = data_overall;
      //  this.overallRatingDetails.isActive = true;
        
     // debugger;
  
    
    } 
    }).catch(error => {
      this.isLoading = false;
      this.overallRatingDetails = [];
    });
  
         
        }
      }).catch(error => {
        this.isLoadingPop = false;
        this.errMsgPop = 'Error saving kra1 data..';
      });
    }
  }).catch(error => {
      this.isLoadingPop = false;
      this.errMsgPop = 'Error saving kra1 data..';
    });
      this.isLoading = false;
      this.reInitDatatable();
      //this.disableButtons = false;
  }
  getTotalWeightage(){
    this.totalWeightage = 0;
    for(let i=0;i<this.current.length;i++) 
     this.totalWeightage = (+this.totalWeightage + +this.current[i].weightage);
  }
  totalWeightageNext = 0;
  
  getTotalWeightageNextYr(){
    this.totalWeightageNext = 0;
    for(let i=0;i<this.nextYr.length;i++){
     console.log(this.nextYr[i].weightage);
     this.totalWeightageNext = (+this.totalWeightageNext + +this.nextYr[i].weightage);
    }
  }
  checkInitiated(){
    
    this.httpService.getById(APIURLS.BR_MASTER_SOFTSKILL_GET_BY_API,this.roleid).then((data_softmaster: any) => {
      if (data_softmaster.length>0) {
        // debugger;  
        this.assessmentMasterList = data_softmaster;
        
        for(let des of this.assessmentMasterList){
          des.self_assessment_rating = [true, true,true, true, true];
          des.setSelfRating = 0;
          des.finalRating = 0;
          des.final_assessment_rating = [true, true,true, true, true];
            this.temp.push(des);
        }
      }
      // else 
      //   this.errMsgPop = data_softmaster.message;
      
         }).catch(error => {
  this.isLoadingPop = false;
  this.errMsgPop = 'Error retreiving softskill master data..';
  });
// //check for any record entries in any of the tables
//     this.httpService.getById(APIURLS.BR_MASTER_ASSESMENT_MASTER_DATA_ANY_API, this.usrid).then((data: any) => {
//       if (data.length > 0) {
//         // debugger;
//         this.assessmentItem = data;
//       // this.assessmentItem.jobDescription = data['0']['jobDescription'];
//         // this.assessmentItem.id = data['0']['id'];
//         this.httpService.getById(APIURLS.BR_KRACURRENTYEAR_GETANY_API, this.assessmentItem.id).then((data_curyr: any) => {
//           if (data_curyr.length == 0) {
//             this.httpService.getById(APIURLS.BR_MASTER_ASSESMENT_DATA_ANY_API, +this.assessmentId).then((data_soft: any) => {
//               if (data_soft.length == 0) {
                  
  
//   this.httpService.getById(APIURLS.BR_KRANEXTYEAR_GETANY_API, +this.assessmentId).then((data_nxyr: any) => {
//     if (data_nxyr.length == 0) {
//       this.errMsgPop = "Apprisal form not initiated";
//       this.router.navigateByUrl('/pcpform');
//     }
    
//     }).catch(error => {
//       this.isLoadingPop = false;
//       this.errMsgPop = 'Error saving kra1 data..';
//     });
                
//                }
//               }).catch(error => {
//           this.isLoadingPop = false;
//           this.errMsgPop = 'Error';
//       });
            
//           }
//         }).catch(error => {
//           this.isLoadingPop = false;
//           this.errMsgPop = 'Error';
//         });
  
//   }
//     }).catch(error => {
//       this.isLoadingPop = false;
//       this.errMsgPop = 'Error';
//     });
   
  }

//   saveDetails(){
//     //console.log('going to save data');
//     this.errMsg = "";
//       this.errMsgPop = "";
//       let connection: any;
//   //  debugger;

//     for(let i =0; i<this.current.length;i++){
//       this.currentKra[i].assessmentAppraisee = this.current[i].selfRating;
//       this.currentKra[i].assessmentAppraiser = this.current[i].finalRating;
//       this.currentKra[i].targetDate = this.current[i].closure_date;
//     }
//       for(let da of this.currentKra){
//               connection = this.httpService.put(APIURLS.BR_KRACURRENTYEAR_API, da.id, da);
//               connection.then((data_kc: any) => {
//               if (data_kc==200) {
//               //console.log('Current KRA Data saved successfully!!!');
//               }
//               // else 
//               //   this.errMsgPop = data_kc.message;
              
//               }).catch(error => {
//                 this.isLoadingPop = false;
//                 this.errMsgPop = 'Error saving kra1 data..';
//               });
//             }

//             //save softskills
//             let itemId = 0;
//             for(let i =0; i<this.temp.length;i++){
//               itemId = this.temp[i].id;
//               this.assessmentDetailsList1[i].fkAssesmentId = this.assessmentId;
//               this.assessmentDetailsList1[i].fkSoftSkillId = itemId;
//               this.assessmentDetailsList1[i].assesmentAppraisee = this.temp[i].selfRating;
//               this.assessmentDetailsList1[i].assesmentAppraiser = this.temp[i].finalRating;
//               //console.log('lllllllll:'+this.temp[i].id+ '<-id, finalratin ->'+this.temp[i].finalRating+', '+this.assessmentDetailsList1[i].assesmentAppraiser);

                      

// // if(this.assessmentDetailsList1[i].finalRating > 0 && this.assessmentDetailsList1[i].selfRating >0)
// // {
//   connection = this.httpService.put(APIURLS.BR_MASTER_ASSESSMENT_DETAILS_API, this.assessmentDetailsList1[i].id, this.assessmentDetailsList1[i]);
//   connection.then((data_ad: any) => {
//     //console.log(data_ad);
//   if (data_ad==200) {
//   //console.log('Current Softskills Data saved successfully!!!');
//   }
//   // else 
//   // {
//   //   this.errMsgPop = data_ad.message;
//   // }
//   }).catch(error => {
//     this.isLoadingPop = false;
//     this.errMsgPop = 'error';
//   });
//              }

                    
//                     // overall rating details
//                     // debugger;
//                     this.getOverallRating();
//                       this.overallRatingItem.fkAssesmentId = this.assessmentId;
//                       this.overallRatingItem.isActive = true;
//                       this.overallRatingItem.ratingEmp = +this.totalEmpScore + +this.sofSkillFinalScoreEmp;
//                       this.overallRatingItem.rating = +this.totalScore + +this.sofSkillFinalScore;
//                       if(this.overallRatingRecordFound)
//                       connection = this.httpService.put(APIURLS.BR_DETAILS_PUT_OVERALLRATING_API, this.overallRatingItem.id, this.overallRatingItem);
                    
//                     else
//                       connection = this.httpService.post(APIURLS.BR_DETAILS_PUT_OVERALLRATING_API, this.overallRatingItem);

//                       connection.then((data: any) => {
//                         if (data==200) {
//                           //console.log('Overall rating details Data saved successfully!!!');
//                           }
//                           // else 
//                           //   this.errMsgPop = data.message;
                          
//                           }).catch(error => {
//                             this.isLoadingPop = false;
//                             this.errMsgPop = 'data error';
//                           });
                        

//                     //training details
//                     // debugger;
                    
//                       this.trainingItem.isActive = true;
//                       this.trainingItem.fkAssesmentId = this.assessmentItem.id;
//                       this.trainingItem.isActive = true;
                     
//                       if(this.trainingRecordFound)
//                         connection = this.httpService.put(APIURLS.BR_DETAILS_PUT_TRAINING_API, this.trainingItem.id, this.trainingItem);
//                       else                      
//                         connection = this.httpService.post(APIURLS.BR_DETAILS_PUT_TRAINING_API, this.trainingItem);

//                       connection.then((data: any) => {
//                         if (data==200) {
//                           //console.log('Training details Data saved successfully!!!');
//                           }
//                           // else 
//                           //   this.errMsgPop = data.message;
                          
//                           }).catch(error => {
//                             this.isLoadingPop = false;
//                             this.errMsgPop = 'Error saving training details data..';
//                           });
                        

//               //save nextyrKRA
//               for(let i=0;i<this.nextYr.length;i++){
//                 //console.log('->'+this.nextYr[i].closure_date);
//                 this.nextKra[i].targetDate = this.nextYr[i].closure_date
//               }
              
//                 for(let da of this.nextKra){
//                         connection = this.httpService.put(APIURLS.BR_MASTER_NEXTYEARKRA_API, da.id, da);
//                         connection.then((data: any) => {
//                          if (data==200){
//                         //console.log('Current Next Year KRA Data saved successfully!!!');
//                         }
//                         }).catch(error => {
//                           this.isLoadingPop = false;
//                           this.errMsgPop = 'Error saving kra1 data..';
//                         });
//                       }
//                       // this.redirecturl = '/approvalempplyee';
//                        // debugger;
//                       //save recommendation details

//                       this.recommItem.isActive = true;
//                       this.recommItem.fkManagerId = this.usrid;
//                       this.recommItem.fkCalenderId = this.calenderId;
//                       this.recommItem.employeeId = this.eid+'';
//                       this.recommItem.fkEmpId = this.employeeid;
//                       this.recommItem.fkRecommendationDesignation = this.selParentRole.id;
//                       this.recommItem.fkAssesmentId = this.assessmentId;

//                       if(this.recommendationRecordFound)
//                         connection = this.httpService.put(APIURLS.BR_DETAIL_APPRAISAL_POST_API, this.recommItem.id, this.recommItem);
//                       else
//                         connection = this.httpService.post(APIURLS.BR_DETAIL_APPRAISAL_POST_API, this.recommItem);
  
//                         connection.then((data: any) => {
//                           if (data==200) {
//                             //console.log('Recommendation details Data saved successfully!!!');
//                             }
//                             // else 
//                             //   this.errMsgPop = data.message;
                            
//                             }).catch(error => {
//                               this.isLoadingPop = false;
//                               this.errMsgPop = 'Error saving recommendation details data..';
//                             });
//                             jQuery("#myModalAllData").modal('hide');
//                             jQuery("#myModal").modal('show');
//                             this.errMsgPop = "PCP form has been saved successfully!!! Please approve the employee PCP form as soon as possible!'";
//                             this.getDesignationMasterList();
                           
//   }

  validateForm(){
    if(this.totalWeightage == 100){
      this.validatedForm = true;
    }
    else{
      this.validatedForm = false;
      this.errMsgPop = 'Total weightage should be 100' ;
    }
  }

  approveapprove(assid: number){
    this.isLoading = true;
    this.assessmentapproveId= assid;
    this.httpService.getById(APIURLS.BR_DETAILS_ANY_OVERALLRATING_API, this.assessmentapproveId).then((data: any) => {
      this.assessmentItem = data;
      if (data.length>0) {
    this.assessmentapproveId= assid;
    //console.log('this.assessmentapproveId')
    //console.log(this.assessmentapproveId)
    this.httpService.getById(APIURLS.BR_MASTER_ASSESMENT_API, this.assessmentapproveId).then((data: any) => {
      this.assessmentItem = data;
      let connection: any;
      //assesment Master update
      this.assessmentItem.formStatus = true;
      this.assessmentItem.employeePcpStatus="Approved by SBU";
      this.assessmentItem.isApprovedBySecondLevel = true;
 
      connection = this.httpService.put(APIURLS.BR_MASTER_ASSESMENT_API, this.assessmentapproveId, this.assessmentItem);
       connection.then((data_asses: any) => {
      if (data_asses==200) {
        this.reInitDatatable();
        this.isLoading = false;
        jQuery("#myModalAllData").modal('hide');
        jQuery("#myModal").modal('show');
        this.errMsgPop = "Approved successfully!!! Thank you'";
      }
      this.getDesignationMasterList();
      }).catch(error => {
        this.isLoadingPop = false;
        this.errMsgPop = 'Error saving Assessment data..';
      }); 
    }).catch(error => {
      this.isLoadingPop = false;
      this.errMsgPop = 'Error saving Assessment data..';
    });        
     }
      else
      this.errMsgPop = "PCP form cannot be submitted";
      });



  }
  closeMessModal() {
    // //console.log('testpop')
    jQuery("#myMessModal").modal('hide');
    
    // window.location.reload();
  }
  // submitForm(){
  //           // this.saveDetails();
  //           this.validateForm();
  //           // debugger;
  //           if(this.validatedForm){
  //             let connection: any;
  //             //assesment Master update
  //             this.assessmentItem.formStatus = true;
  //             this.assessmentItem.employeePcpStatus="Approved by Management";
  //             this.assessmentItem.isApprovedBySecondLevel = true;

  //             connection = this.httpService.put(APIURLS.BR_MASTER_ASSESMENT_API, this.assessmentItem.id, this.assessmentItem);
  //             connection.then((data_asses: any) => {
  //             if (data_asses==200) {
  //               // this.redirecturl = '/approvalempplyee';
  //               jQuery("#myModalAllData").modal('hide');
  //               jQuery("#myMessModal").modal('show');
  //               this.errMsgPop1 = "PCP form has been Submitted successfully!!! Thank you'";
  //             }
  //             this.getDesignationMasterList();
  //             // else 
  //             //   this.errMsgPop = data.message;
              
  //             }).catch(error => {
  //               this.isLoadingPop = false;
  //               this.errMsgPop = 'Error saving Assessment data..';
  //             });         
  //           // }
  //           // else{
  //           //   this.errMsgPop = this.errMsgPop + ' '+'Form cannot be submitted!';
  //           // }     
  // // }})};
  //           }else
  //           this.errMsgPop = "PCP form cannot be submitted";
  //         }

  submitForm(){
    // this.saveDetails();
    // this.validateForm();
    debugger;
    this.validatedForm = true;
    // this.disableButtons = true;
    this.isLoading = true;
    // let recomTab: boolean = true;
    let recomLess: boolean = true;
    let recomSum: boolean = true;
      // if(this.recommItem.fkRecommendationDesignation==null || this.recommItem.recommendationHike<0 || +this.recommItem.fixedHike<0 || this.recommItem.variableHike<0 || this.recommItem.variableIncentive<0 || this.recommItem.comments==undefined || this.recommItem.comments==""){
      //   this.validatedForm = false;
      //   recomTab = false;
      //   // this.errMsgPop= 'Please fill all entries in recommendations correctly' ;
      //   // // throw Error();
      //   // return;
      // }else 
      // if(recomTab && (this.recommItem.recommendationHike < this.recommItem.fixedHike||this.recommItem.recommendationHike < this.recommItem.variableHike)){
      // if((this.recommItem.recommendationHike < this.recommItem.fixedHike||this.recommItem.recommendationHike < this.recommItem.variableHike)){
      //   this.validatedForm = false;
      //   recomLess = false;
      // }else if(recomLess ){
      //   let recSum = +this.recommItem.variableHike + +this.recommItem.fixedHike;
      //   if(this.recommItem.recommendationHike!=recSum){
      //     this.validatedForm = false;
      //     recomSum = false;
      //   }
      // }
    
      let connection: any;
    
    if(this.validatedForm){
      swal({ title: "Are you sure?", 
        text: "Once Submitted, you will not be able to edit the PCP form!",
        icon: "warning",
        dangerMode: false,
        buttons: [true, true]
      })
      .then((willDelete) => {
        if (willDelete) {

          this.recommItem.isActive = true;
      this.recommItem.fkManagerId = this.usrid;
      this.recommItem.fkCalenderId = this.calenderId;
      this.recommItem.employeeId = this.eid+'';
      this.recommItem.fkEmpId = this.employeeid;
      this.recommItem.fkRecommendationDesignation = this.selParentRole.id;
      this.recommItem.fkAssesmentId = this.assessmentId;

      
        connection = this.httpService.put(APIURLS.BR_DETAIL_APPRAISAL_POST_API, this.recommItem.id, this.recommItem);
      

        connection.then((data: any) => {
          if (data==200) {
            console.log('Recommendation details Data saved successfully!!!');
            }
            // else 
            //   this.errMsgPop = data.message;
            
            }).catch(error => {
              this.isLoadingPop = false;
              this.errMsgPop = 'Error saving recommendation details data..';
            });


      //assesment Master update
      this.assessmentItem.formStatus = true;
      this.assessmentItem.employeePcpStatus="Approved by Management";
      this.assessmentItem.isApprovedBySecondLevel = true;
      this.assessmentItem.isApprovedByFirstLevel = true;
      this.assessmentItem.isApprovedByThirdLevel = true;
      this.assessmentItem.isApprovedByFourthLevel = true;
      this.assessmentItem.isApprovedByFifthLevel = true;

      connection = this.httpService.put(APIURLS.BR_MASTER_ASSESMENT_API, this.assessmentItem.id, this.assessmentItem);
      connection.then((data_asses: any) => {
      if (data_asses==200) {
        // this.redirecturl = '/approvalempplyee';
        jQuery("#myModalAllData").modal('hide');
        
        jQuery("#myMessModal").modal('show');
        // jQuery("#myModal").modal('show');
        this.errMsgPop1 = "PCP form has been Approved Successfully!! Thank you!";
      }
      this.getDesignationMasterList();
      // else 
      //   this.errMsgPop = data.message;
      
      }).catch(error => {
        this.isLoadingPop = false;
        this.errMsgPop = 'Error saving Assessment data..';
      });    
          // swal("Poof! Your imaginary file has been deleted!", {
          //   icon: "success",
          // });
        } else {
          // swal("Please proceed to fill!");
          this.isLoadingPop = false;
          this.isLoading = false;
          // this.disableButtons = false;
        }
      });
           
    // }
    // else{
    //   this.errMsgPop = this.errMsgPop + ' '+'Form cannot be submitted!';
    // }     
// }})};
    }else{
    let errMsg = ''
    // if(!recomTab)
    //   errMsg =  'Please fill all entries in Recommendations correctly' ;
    //   else 
      if(!recomLess)
      errMsg =  'Fixed and Variable Hike total should equals Recommended Hike' ;
      else if(!recomSum)
      errMsg =  'Fixed and Variable Hike total should equals Recommended Hike' ;
      this.isLoadingPop = false;
      this.errMsgPop = errMsg;
      this.isLoading = false;
      // this.disableButtons = false;
      jQuery("#myModalAllData").scrollTop(0);
  }
}
          resubmitEmployee(){
            let connection: any;
            this.assessmentItem.formStatus = false;
            this.assessmentItem.isApprovedByFirstLevel = false;
            this.assessmentItem.isApprovedBySecondLevel = false;
            this.assessmentItem.isApprovedByThirdLevel = false;
            this.assessmentItem.isApprovedByFourthLevel = false;
              this.assessmentItem.employeePcpStatus="Re-submit form to Manager";
              
              connection = this.httpService.put(APIURLS.BR_MASTER_ASSESMENT_API, this.assessmentItem.id, this.assessmentItem);
              connection.then((data_asses: any) => {
              if (data_asses==200) {
                // this.redirecturl = '/approvalempplyee';
                jQuery("#myModalAllData").modal('hide');
                jQuery("#myMessModal").modal('show');
                this.errMsgPop1 = "Requested Manager to re-submit PCP form";
                
              }
              this.getDesignationMasterList();
              }).catch(error => {
                this.isLoadingPop = false;
                this.errMsgPop = 'Error saving Assessment data..';
              });         
          }
          resubmitManager(){
            let connection: any;
            this.assessmentItem.formStatus = true;
            this.assessmentItem.isApprovedByFirstLevel = false;
            this.assessmentItem.isApprovedBySecondLevel = false;
            this.assessmentItem.isApprovedByThirdLevel = false;
            this.assessmentItem.isApprovedByFourthLevel = false;
              this.assessmentItem.employeePcpStatus="Re-submit form to Manager";
              
              connection = this.httpService.put(APIURLS.BR_MASTER_ASSESMENT_API, this.assessmentItem.id, this.assessmentItem);
              connection.then((data_asses: any) => {
              if (data_asses==200) {
                // this.redirecturl = '/approvalempplyee';
                jQuery("#myModalAllData").modal('hide');
                jQuery("#myMessModal").modal('show');
                this.errMsgPop1 = "Requested Manager to re-submit PCP form";
                
              }
              this.getDesignationMasterList();
              }).catch(error => {
                this.isLoadingPop = false;
                this.errMsgPop = 'Error saving Assessment data..';
              });         
          }
          resubmitSBU(){
            let connection: any;
            this.assessmentItem.formStatus = true;
            this.assessmentItem.isApprovedByFirstLevel = true;
            this.assessmentItem.isApprovedBySecondLevel = true;
            this.assessmentItem.isApprovedByThirdLevel = true;
            this.assessmentItem.isApprovedByFourthLevel = false;
              this.assessmentItem.employeePcpStatus="Re-submit form to SBU";
              
              connection = this.httpService.put(APIURLS.BR_MASTER_ASSESMENT_API, this.assessmentItem.id, this.assessmentItem);
              connection.then((data_asses: any) => {
              if (data_asses==200) {
                // this.redirecturl = '/approvalempplyee';
                jQuery("#myModalAllData").modal('hide');
                jQuery("#myMessModal").modal('show');
                this.errMsgPop1 = "Requested SBU to re-submit PCP form";
                
              }
              this.getDesignationMasterList();
              }).catch(error => {
                this.isLoadingPop = false;
                this.errMsgPop = 'Error saving Assessment data..';
              });         
          }

}
